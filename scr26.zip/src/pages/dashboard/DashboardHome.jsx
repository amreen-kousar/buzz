import React from 'react'
import { Outlet } from 'react-router-dom'

function DashboardHome() {
    return (
        <Outlet />
    )
}

export default DashboardHome