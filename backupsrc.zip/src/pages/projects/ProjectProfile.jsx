import React from 'react'

function ProjectProfile() {
  return (
    <div>ProjectProfile</div>
  )
}

export default ProjectProfile