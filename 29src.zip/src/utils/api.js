const baseURL = "https://bdms.buzzwomen.org/appGo/";
const oldbaseURL = "https://bdms.buzzwomen.org/appTest/"

module.exports = {baseURL,oldbaseURL}
